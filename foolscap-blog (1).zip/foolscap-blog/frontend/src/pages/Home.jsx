import { useEffect, useState, useCallback } from 'react';
import { useSearchParams } from 'react-router-dom';
import api from '../api/axios';
import PostCard from '../components/PostCard';
import FeaturedPost from '../components/FeaturedPost';

export default function Home() {
  const [posts, setPosts] = useState([]);
  const [allTags, setAllTags] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [searchParams, setSearchParams] = useSearchParams();
  const search = searchParams.get('search') || '';
  const tag = searchParams.get('tag') || '';
  const [searchInput, setSearchInput] = useState(search);

  const fetchPosts = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const params = {};
      if (search) params.search = search;
      if (tag) params.tag = tag;
      const { data } = await api.get('/posts', { params });
      setPosts(data.posts);
    } catch (err) {
      setError(err.response?.data?.message || 'Could not load posts');
    } finally {
      setLoading(false);
    }
  }, [search, tag]);

  // Build the tag cloud independently of the current filter, so it doesn't
  // shrink to nothing when a tag or search is already applied
  useEffect(() => {
    api.get('/posts', { params: { limit: 50 } }).then(({ data }) => {
      const unique = [...new Set(data.posts.flatMap((p) => p.tags || []))];
      setAllTags(unique.slice(0, 10));
    }).catch(() => {});
  }, []);

  useEffect(() => {
    fetchPosts();
  }, [fetchPosts]);

  const handleSearchSubmit = (e) => {
    e.preventDefault();
    const next = {};
    if (searchInput) next.search = searchInput;
    if (tag) next.tag = tag;
    setSearchParams(next);
  };

  const handleTagClick = (clickedTag) => {
    const next = {};
    if (search) next.search = search;
    if (clickedTag !== tag) next.tag = clickedTag;
    setSearchParams(next);
  };

  const isFiltered = Boolean(search || tag);
  const featured = !isFiltered && posts.length > 0 ? posts[0] : null;
  const rest = featured ? posts.slice(1) : posts;

  return (
    <div className="max-w-5xl mx-auto px-6 py-12">
      <div className="mb-8">
        <h1 className="font-display text-4xl font-semibold mb-2">
          {isFiltered ? 'Browsing' : 'Latest entries'}
        </h1>
        <p className="text-ink-soft">
          {search && `Results for "${search}". `}
          {tag && `Tagged "${tag}". `}
          {!isFiltered && 'Fresh writing from the Foolscap community.'}
        </p>
      </div>

      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-10">
        <form onSubmit={handleSearchSubmit} className="flex gap-2 w-full sm:max-w-xs">
          <input
            type="text"
            value={searchInput}
            onChange={(e) => setSearchInput(e.target.value)}
            placeholder="Search posts…"
            className="flex-1 border border-hairline rounded-full px-5 py-2 text-sm focus:border-teal outline-none"
          />
          <button
            type="submit"
            className="rounded-full bg-ink text-paper px-4 py-2 text-sm font-medium hover:bg-teal-dark transition-colors"
          >
            Search
          </button>
        </form>

        {allTags.length > 0 && (
          <div className="flex gap-2 flex-wrap">
            {allTags.map((t) => (
              <button
                key={t}
                onClick={() => handleTagClick(t)}
                className={`text-xs font-mono px-2.5 py-1 rounded-full transition-colors ${
                  tag === t ? 'bg-teal-dark text-paper' : 'bg-amber-soft text-ink-soft hover:text-ink'
                }`}
              >
                {t}
              </button>
            ))}
          </div>
        )}

        {isFiltered && (
          <button
            onClick={() => { setSearchInput(''); setSearchParams({}); }}
            className="text-sm text-ink-soft hover:text-rust"
          >
            Clear filters
          </button>
        )}
      </div>

      {loading && <p className="text-ink-soft font-mono text-sm">Loading posts…</p>}
      {error && <p className="text-rust text-sm">{error}</p>}

      {!loading && !error && posts.length === 0 && (
        <div className="border border-dashed border-hairline rounded-lg py-16 text-center">
          <p className="text-ink-soft">
            {isFiltered ? 'Nothing matches that yet.' : 'No posts have been published yet.'}
          </p>
        </div>
      )}

      {featured && <FeaturedPost post={featured} />}

      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-x-8 gap-y-10">
        {rest.map((post) => (
          <PostCard key={post._id} post={post} />
        ))}
      </div>
    </div>
  );
}
