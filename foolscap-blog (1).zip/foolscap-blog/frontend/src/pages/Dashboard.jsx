import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Plus, Pencil, Trash2 } from 'lucide-react';
import api from '../api/axios';
import { useAuth } from '../context/AuthContext';
import Monogram from '../components/Monogram';
import toast from 'react-hot-toast';

export default function Dashboard() {
  const { user } = useAuth();
  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchMine = async () => {
      try {
        const { data } = await api.get('/posts', { params: { mine: true, limit: 50 } });
        setPosts(data.posts);
      } catch (err) {
        toast.error('Could not load your posts');
      } finally {
        setLoading(false);
      }
    };
    fetchMine();
  }, []);

  const handleDelete = async (id) => {
    if (!window.confirm('Delete this post? This cannot be undone.')) return;
    try {
      await api.delete(`/posts/${id}`);
      setPosts(posts.filter((p) => p._id !== id));
      toast.success('Post deleted');
    } catch (err) {
      toast.error(err.response?.data?.message || 'Could not delete post');
    }
  };

  return (
    <div className="max-w-3xl mx-auto px-6 py-12">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="font-display text-3xl font-semibold mb-1">Your posts</h1>
          <p className="text-ink-soft">Signed in as {user?.name}</p>
        </div>
        <Link
          to="/new"
          className="flex items-center gap-1.5 rounded-full bg-ink text-paper px-5 py-2.5 text-sm font-medium hover:bg-teal-dark transition-colors"
        >
          <Plus size={15} /> New post
        </Link>
      </div>

      {loading && <p className="text-ink-soft font-mono text-sm">Loading…</p>}

      {!loading && posts.length === 0 && (
        <div className="border border-dashed border-hairline rounded-lg py-16 text-center">
          <p className="text-ink-soft mb-4">You haven't written anything yet.</p>
          <Link to="/new" className="text-teal-dark font-medium hover:underline">
            Write your first post
          </Link>
        </div>
      )}

      <div className="space-y-3">
        {posts.map((post) => (
          <div
            key={post._id}
            className="flex items-center gap-4 bg-paper border border-hairline rounded-xl p-3"
          >
            <div className="w-16 h-16 rounded-lg overflow-hidden flex-shrink-0 border border-hairline">
              {post.coverImage ? (
                <img src={post.coverImage} alt="" className="w-full h-full object-cover" />
              ) : (
                <Monogram title={post.title} className="w-full h-full" textSizeClass="text-xl" />
              )}
            </div>

            <div className="flex-1 min-w-0">
              <Link
                to={`/posts/${post.slug}`}
                className="font-display text-lg font-semibold hover:text-teal-dark transition-colors truncate block"
              >
                {post.title}
              </Link>
              <div className="flex items-center gap-2 text-xs font-mono text-ink-soft mt-1">
                <span>{new Date(post.createdAt).toLocaleDateString()}</span>
                <span>·</span>
                <span
                  className={`px-1.5 py-0.5 rounded ${
                    post.published ? 'bg-teal-soft text-teal-dark' : 'bg-amber-soft text-amber'
                  }`}
                >
                  {post.published ? 'Published' : 'Draft'}
                </span>
              </div>
            </div>

            <div className="flex gap-1 flex-shrink-0">
              <Link
                to={`/posts/${post.slug}/edit`}
                className="p-2 rounded-lg text-ink-soft hover:text-teal-dark hover:bg-panel transition-colors"
                aria-label="Edit post"
              >
                <Pencil size={16} />
              </Link>
              <button
                onClick={() => handleDelete(post._id)}
                className="p-2 rounded-lg text-ink-soft hover:text-rust hover:bg-panel transition-colors"
                aria-label="Delete post"
              >
                <Trash2 size={16} />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
