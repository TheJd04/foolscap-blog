import { Link } from 'react-router-dom';
import Monogram from './Monogram';

export default function FeaturedPost({ post }) {
  const date = new Date(post.createdAt).toLocaleDateString('en-US', {
    weekday: 'long', month: 'long', day: 'numeric',
  });

  return (
    <article className="grid md:grid-cols-2 gap-8 items-center pb-10 mb-10 border-b border-hairline">
      <div>
        <p className="text-xs font-mono uppercase tracking-wide text-teal-dark mb-3">
          Latest entry
        </p>
        <h2 className="font-display text-3xl md:text-4xl font-semibold leading-tight mb-3">
          <Link to={`/posts/${post.slug}`} className="text-ink hover:text-teal-dark transition-colors">
            {post.title}
          </Link>
        </h2>
        <p className="text-ink-soft leading-relaxed mb-4">{post.excerpt}</p>
        <div className="flex items-center gap-3 text-xs font-mono text-ink-soft mb-5">
          <span>{post.author?.name || 'Unknown'}</span>
          <span aria-hidden="true">·</span>
          <span>{date}</span>
        </div>
        <Link
          to={`/posts/${post.slug}`}
          className="inline-flex items-center gap-1.5 text-sm font-medium text-teal-dark hover:text-teal transition-colors"
        >
          Read the full entry <span aria-hidden="true">→</span>
        </Link>
      </div>

      <Link to={`/posts/${post.slug}`} className="block order-first md:order-last">
        <div className="aspect-[4/3] rounded-xl overflow-hidden border border-hairline">
          {post.coverImage ? (
            <img src={post.coverImage} alt="" className="w-full h-full object-cover" />
          ) : (
            <Monogram title={post.title} className="w-full h-full" textSizeClass="text-7xl" />
          )}
        </div>
      </Link>
    </article>
  );
}
