import { Link } from 'react-router-dom';
import Monogram from './Monogram';

export default function PostCard({ post }) {
  const date = new Date(post.createdAt).toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
  });

  return (
    <article className="group">
      <Link to={`/posts/${post.slug}`} className="block">
        <div className="aspect-[4/3] rounded-lg overflow-hidden mb-3 border border-hairline">
          {post.coverImage ? (
            <img
              src={post.coverImage}
              alt=""
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
            />
          ) : (
            <Monogram title={post.title} className="w-full h-full" textSizeClass="text-5xl" />
          )}
        </div>
      </Link>

      <div className="flex items-center gap-2 text-xs font-mono text-ink-soft mb-1.5">
        <span>{date}</span>
        <span aria-hidden="true">·</span>
        <span className="truncate">{post.author?.name || 'Unknown'}</span>
      </div>

      <h3 className="font-display text-xl font-semibold leading-snug mb-1.5">
        <Link to={`/posts/${post.slug}`} className="text-ink group-hover:text-teal-dark transition-colors">
          {post.title}
        </Link>
      </h3>

      <p className="text-sm text-ink-soft leading-relaxed line-clamp-2 mb-2">{post.excerpt}</p>

      {post.tags?.length > 0 && (
        <div className="flex gap-1.5 flex-wrap">
          {post.tags.slice(0, 3).map((tag) => (
            <span key={tag} className="text-xs font-mono px-2 py-0.5 rounded-full bg-amber-soft text-ink-soft">
              {tag}
            </span>
          ))}
        </div>
      )}
    </article>
  );
}
