export default function FoolscapMark({ size = 28 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 28 28" fill="none" aria-hidden="true">
      {/* Pen nib silhouette */}
      <path
        d="M14 2L24 13C24 19.5 19.5 24.5 14 26C8.5 24.5 4 19.5 4 13L14 2Z"
        fill="var(--color-ink)"
      />
      <path d="M14 11V26" stroke="var(--color-paper)" strokeWidth="1.2" />
      <circle cx="14" cy="14.5" r="1.6" fill="var(--color-teal)" />
    </svg>
  );
}
