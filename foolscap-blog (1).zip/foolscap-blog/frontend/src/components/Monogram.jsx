const TINTS = ['var(--color-panel)', 'var(--color-amber-soft)', 'var(--color-teal-soft)'];

// Deterministic tint per title, so a given post always renders the same way
function tintFor(title) {
  const sum = title.split('').reduce((acc, ch) => acc + ch.charCodeAt(0), 0);
  return TINTS[sum % TINTS.length];
}

export default function Monogram({ title, className = '', textSizeClass = 'text-4xl' }) {
  const letter = (title || '?').trim().charAt(0).toUpperCase();
  return (
    <div
      className={`flex items-center justify-center ${className}`}
      style={{ backgroundColor: tintFor(title || '') }}
      aria-hidden="true"
    >
      <span
        className={`font-display font-semibold leading-none ${textSizeClass}`}
        style={{ color: 'var(--color-teal-dark)' }}
      >
        {letter}
      </span>
    </div>
  );
}
