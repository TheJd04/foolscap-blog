import { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import api from '../api/axios';
import FoolscapMark from './FoolscapMark';

const today = new Date().toLocaleDateString('en-US', {
  weekday: 'long',
  year: 'numeric',
  month: 'long',
  day: 'numeric',
});

export default function Navbar() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [issueNo, setIssueNo] = useState(null);

  useEffect(() => {
    api.get('/posts', { params: { limit: 1 } })
      .then(({ data }) => setIssueNo(data.total))
      .catch(() => {});
  }, []);

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  return (
    <header className="border-b border-hairline bg-paper">
      {/* Dateline strip — newspaper-style detail, sets the editorial tone */}
      <div className="hidden sm:flex items-center justify-center gap-3 text-center text-xs font-mono tracking-wide text-ink-soft py-1.5 border-b border-hairline bg-panel">
        <span>{today}</span>
        {issueNo !== null && (
          <>
            <span aria-hidden="true">·</span>
            <span>Vol. 1, No. {issueNo}</span>
          </>
        )}
      </div>

      <div className="max-w-5xl mx-auto px-6 py-4 sm:py-5 flex flex-wrap items-center justify-between gap-y-3 gap-x-4">
        <Link to="/" className="flex items-center gap-2.5">
          <FoolscapMark size={26} />
          <span className="flex items-baseline gap-2">
            <span className="font-display text-2xl sm:text-3xl font-semibold tracking-tight text-ink">
              Foolscap
            </span>
            <span className="hidden md:inline text-xs font-mono text-ink-soft">
              — write things down
            </span>
          </span>
        </Link>

        <nav className="flex items-center gap-3 sm:gap-5 text-sm font-medium whitespace-nowrap">
          <Link to="/" className="text-ink hover:text-teal transition-colors">
            Read
          </Link>

          {user ? (
            <>
              <Link to="/new" className="text-ink hover:text-teal transition-colors">
                Write
              </Link>
              <Link to="/dashboard" className="text-ink hover:text-teal transition-colors">
                My posts
              </Link>
              <span className="hidden sm:inline text-ink-soft font-mono text-xs">
                {user.name}
              </span>
              <button
                onClick={handleLogout}
                className="rounded-full border border-hairline px-4 py-1.5 hover:border-rust hover:text-rust transition-colors"
              >
                Log out
              </button>
            </>
          ) : (
            <>
              <Link to="/login" className="text-ink hover:text-teal transition-colors">
                Log in
              </Link>
              <Link
                to="/signup"
                className="rounded-full bg-ink px-4 py-1.5 text-paper hover:bg-teal-dark transition-colors"
              >
                Sign up
              </Link>
            </>
          )}
        </nav>
      </div>
    </header>
  );
}
